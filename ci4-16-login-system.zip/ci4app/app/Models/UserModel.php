<?php

namespace App\Models;

use CodeIgniter\Model;

class UserModel extends Model
{
    protected $useTimestamps = true;
    protected $allowedFields = ['username', 'email', 'password', 'level'];

    public function cekLogin($email, $password)
    {
        return $this->db->table('user')
        ->where(array('email' => $email, 'password' => $password))
        ->get()->getRowArray();
    }
}