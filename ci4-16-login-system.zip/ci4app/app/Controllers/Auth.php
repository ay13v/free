<?php

namespace App\Controllers;

use App\Models\UserModel;

class Auth extends BaseController
{
	public function __construct()
	{
		$this->userModel = new UserModel();
	}

	public function index()
	{
		return view('/auth/index.php');
	}

	public function cekLogin()
	{
		$email = $this->request->getVar('email');
		$password = $this->request->getVar('password');

		$cek = $this->userModel->cekLogin($email, $password);

		if(($cek['email']==$email) && ($cek['password']==$password)) {
			session()->set('username',$cek['username']);
			session()->set('email',$cek['email']);
			session()->set('level',$cek['level']);
			return redirect()->to('/pages');
		} else {
			session()->setFlashdata('gagal','Username atau Password Salah!');
			return redirect()->to('/auth');
		}
	}

	public function logout()
	{
		session()->destroy();
		return redirect()->to('/auth');
	}

	//--------------------------------------------------------------------

}