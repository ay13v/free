<?php

namespace App\Controllers;

class Pages extends BaseController
{
    public function index()
    {
        if(session()->get('username')==''){
            session()->setFlashdata('gagal','Anda belum login!');
            return redirect()->to('/auth');
        }

        $data = [
            'title' => 'Home | WebProgrammingUNPAS'
        ];
        return view('pages/home', $data);
    }

    public function about()
    {
        if(session()->get('username')==''){
            session()->setFlashdata('gagal','Anda belum login!');
            return redirect()->to('/auth');
        }

        $data = [
            'title' => 'Home | About Me'
        ];
        return view('pages/about', $data);
    }

    public function contact()
    {
        if(session()->get('username')==''){
            session()->setFlashdata('gagal','Anda belum login!');
            return redirect()->to('/auth');
        }

        $data = [
            'title' => 'Contact Us',
            'alamat' => [
                [
                    'tipe' => 'Rumah',
                    'alamat' => 'Jl. abc, No. 123',
                    'kota' => 'Sangatta'
                ],
                [
                    'tipe' => 'Kantor',
                    'alamat' => 'Jl. Sawitopinrang Gg. Panorama Bahari, No. Infinity',
                    'kota' => 'Sangatta'
                ]
            ]

        ];

        return view('pages/contact', $data);
        
    }

    //--------------------------------------------------------------------

}