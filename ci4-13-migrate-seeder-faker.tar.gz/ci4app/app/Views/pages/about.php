<?= $this->extend('layout/template'); ?>

<?= $this->section('content'); ?>
<div class="container">
    <div class="row">
        <div class="about">
            <h1>About Me</h1>
            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Maiores quia aperiam minus? Labore ipsam nulla
                molestias sapiente nemo voluptatem, aperiam ea dolore, deserunt velit recusandae tempora aliquid, libero
                harum?
                Dignissimos.</p>
        </div>
    </div>
</div>
<?= $this->endSection(); ?>